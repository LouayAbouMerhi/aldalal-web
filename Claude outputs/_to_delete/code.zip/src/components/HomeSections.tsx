"use client";

import Link from "next/link";
import { site, whatsappDisplay } from "@/config/site";
import { useRecentProducts } from "@/lib/recent";
import { useReveal } from "@/lib/hooks";
import { whatsappUrl } from "@/lib/whatsapp";
import { ProductRail } from "./ProductRail";
import { CartIcon, ClockIcon, DownloadIcon, PhoneIcon, TagIcon, WhatsAppIcon } from "./icons";

const FEATURES = [
  { icon: TagIcon, title: "Real photos and prices", text: "Every product in the price list, with its photo and price in US dollars." },
  { icon: CartIcon, title: "Build your order", text: "Add what you need, set the quantities, and we price anything that's missing." },
  { icon: WhatsAppIcon, title: "Send it on WhatsApp", text: "One tap sends your whole order to us, ready to confirm." },
  { icon: DownloadIcon, title: "Works like an app", text: "Add it to your phone's home screen and browse even without internet." },
];

export function FeatureStrip() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} data-reveal className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
      <div className="grid gap-px bg-line sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map(({ icon: Icon, title, text }, i) => (
          <div
            key={title}
            style={{ "--reveal-delay": `${i * 70}ms` } as React.CSSProperties}
            className="group bg-paper p-7 transition hover:bg-surface"
          >
            <span className="grid size-11 place-items-center border border-line text-gold-700 transition group-hover:border-gold-500">
              <Icon />
            </span>
            <h3 className="font-display mt-5 text-lg text-ink">{title}</h3>
            <p className="mt-2 text-[13.5px] leading-relaxed text-muted">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function RecentlyViewed({ exclude }: { exclude?: string }) {
  const items = useRecentProducts(exclude);
  if (items.length < 3) return null;
  return (
    <ProductRail
      title="Recently viewed"
      subtitle="Pick up where you left off"
      items={items}
      icon={<ClockIcon className="text-gold-500" />}
    />
  );
}

export function OrderCta() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} data-reveal className="mx-auto max-w-7xl px-4 py-12">
      <div className="relative isolate overflow-hidden border border-line bg-surface px-6 py-16 text-center md:px-12">
        <p className="eyebrow">At your service</p>
        <h2 className="mt-5 text-[clamp(2rem,4vw,3rem)] text-ink">Ready to order?</h2>
        <div className="rule-gold mx-auto my-7 w-16" />
        <p className="mx-auto max-w-lg text-[14.5px] leading-relaxed text-muted">
          Add products to your order and send the list to us on WhatsApp, or call the shop — we&apos;re on the main road in{" "}
          {site.address.replace(/, Lebanon$/, "").replace(/^Sibline, /, "Sibline, ")}.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/products"
            className="inline-flex h-12 items-center gap-2 bg-ink px-7 text-[12px] font-semibold tracking-[0.18em] text-paper uppercase transition hover:bg-wine-600"
          >
            <CartIcon />
            Start an order
          </Link>
          <a
            href={whatsappUrl(`Hello ${site.name}, I would like to order from your price list.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-12 items-center gap-2 bg-forest-600 px-6 text-[12px] font-semibold tracking-[0.18em] text-paper uppercase transition hover:bg-forest-700"
          >
            <WhatsAppIcon />
            WhatsApp {whatsappDisplay}
          </a>
          {site.phones.map((p) => (
            <a
              key={p.tel}
              href={`tel:${p.tel}`}
              className="inline-flex h-12 items-center gap-2 border border-line px-5 text-[12px] font-semibold tracking-[0.16em] text-ink uppercase transition hover:border-gold-400 hover:text-gold-700"
            >
              <PhoneIcon width={18} height={18} />
              {p.display}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
