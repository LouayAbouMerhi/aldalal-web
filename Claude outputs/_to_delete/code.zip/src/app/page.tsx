import { CategoryGrid } from "@/components/CategoryGrid";
import { FeatureStrip, OrderCta, RecentlyViewed } from "@/components/HomeSections";
import { Hero } from "@/components/Hero";
import { ProductRail } from "@/components/ProductRail";
import { homeCollections } from "@/config/collections";
import { catalogHref } from "@/lib/links";

export default function Home() {
  const rails = homeCollections();
  const photos = rails
    .flatMap((r) => r.items)
    .filter((p) => p.image)
    .slice(0, 6)
    .map((p) => ({ src: p.image!.src, alt: p.name }));

  return (
    <>
      <Hero photos={photos} />
      <FeatureStrip />
      {rails.map((rail) => (
        <ProductRail
          key={rail.id}
          title={rail.title}
          subtitle={rail.subtitle}
          items={rail.items}
          href={rail.id === "value" ? catalogHref({ sort: "price-asc" }) : "/products"}
        />
      ))}
      <CategoryGrid />
      <RecentlyViewed />
      <OrderCta />
    </>
  );
}
