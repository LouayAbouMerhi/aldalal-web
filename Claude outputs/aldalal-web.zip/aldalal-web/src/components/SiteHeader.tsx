"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { site } from "@/config/site";
import { formatPrice } from "@/lib/catalog";
import { useScrolled } from "@/lib/hooks";
import { CartIcon, HeartIcon, SearchIcon } from "./icons";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
  { href: "/favorites", label: "Saved" },
];

type Props = {
  cartPieces: number;
  cartSubtotal: number;
  favoriteCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
};

export function SiteHeader({ cartPieces, cartSubtotal, favoriteCount, onOpenCart, onOpenSearch }: Props) {
  const scrolled = useScrolled(12);
  const pathname = usePathname();

  return (
    <header
      className={`sticky top-0 z-40 border-b bg-white transition-shadow duration-300 ${
        scrolled ? "border-line shadow-[0_6px_20px_-12px_rgb(16_36_29/0.25)]" : "border-line"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:gap-5 lg:h-[4.25rem]">
        <Link href="/" className="flex shrink-0 items-center gap-2.5" aria-label={`${site.fullName} – home`}>
          <Image src="/logo.png" alt="" width={40} height={40} preload className="size-10 rounded-xl ring-1 ring-line" />
          <span className="hidden leading-tight sm:block">
            <span className="block text-[17px] font-extrabold tracking-tight text-ink">{site.name}</span>
            <span className="block text-[11px] font-medium text-muted">For General Trading</span>
          </span>
        </Link>

        <nav className="ml-1 hidden items-center gap-1 lg:flex">
          {NAV.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                  active ? "bg-brand-50 text-brand-700" : "text-muted hover:bg-canvas hover:text-ink"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex flex-1 items-center justify-end gap-2">
          <button
            type="button"
            onClick={onOpenSearch}
            className="flex h-11 flex-1 items-center gap-2 rounded-full border border-line bg-canvas px-4 text-left text-sm text-muted transition hover:border-brand-200 hover:bg-brand-50/60 sm:max-w-xs lg:max-w-sm"
            aria-label="Search products"
          >
            <SearchIcon width={18} height={18} className="shrink-0 text-brand-500" />
            <span className="hidden truncate sm:block">Search products…</span>
            <kbd className="ml-auto hidden rounded border border-line px-1.5 text-[11px] lg:block">/</kbd>
          </button>

          <Link
            href="/favorites"
            className="relative hidden size-11 shrink-0 place-items-center rounded-full border border-line text-muted transition hover:border-rose-200 hover:text-rose-500 lg:grid"
            aria-label={`Favorites, ${favoriteCount} saved`}
          >
            <HeartIcon filled={favoriteCount > 0} className={favoriteCount > 0 ? "text-rose-500" : ""} />
            {favoriteCount > 0 && (
              <span className="absolute -top-1 -right-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose-500 px-1 text-[11px] font-bold text-white tabular-nums">
                {favoriteCount > 99 ? "99+" : favoriteCount}
              </span>
            )}
          </Link>

          <button
            type="button"
            onClick={onOpenCart}
            className="relative flex h-11 shrink-0 items-center gap-2 rounded-full bg-brand-500 px-4 font-semibold text-white shadow-sm transition hover:bg-brand-600 active:scale-95 lg:px-5"
            aria-label={`Open cart, ${cartPieces} ${cartPieces === 1 ? "item" : "items"}`}
          >
            <CartIcon width={20} height={20} />
            <span className="hidden text-sm tabular-nums lg:inline">
              {cartPieces > 0 ? formatPrice(cartSubtotal) : "Order"}
            </span>
            {cartPieces > 0 && (
              <span
                key={cartPieces}
                className="badge-pop absolute -top-1.5 -right-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-gold-400 px-1 text-[11px] font-bold text-ink tabular-nums"
              >
                {cartPieces > 99 ? "99+" : cartPieces}
              </span>
            )}
          </button>
        </div>
      </div>
      
    </header>
  );
}
