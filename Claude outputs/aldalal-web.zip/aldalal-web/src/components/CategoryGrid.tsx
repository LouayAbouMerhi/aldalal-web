"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo } from "react";
import { categories, products } from "@/lib/catalog";
import { useReveal } from "@/lib/hooks";
import { catalogHref } from "@/lib/links";
import { ArrowRightIcon } from "./icons";

export function CategoryGrid() {
  const reveal = useReveal<HTMLElement>();
  const covers = useMemo(() => {
    const map = new Map<string, string>();
    for (const p of products) {
      if (p.image && !map.has(p.category)) map.set(p.category, p.image.src);
    }
    return map;
  }, []);

  return (
    <section ref={reveal} data-reveal className="mx-auto max-w-7xl px-4 py-10">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-ink md:text-3xl">Shop by category</h2>
          <p className="mt-1 text-sm text-muted">{categories.length} categories, {products.length} products in total</p>
        </div>
        <Link href="/products" className="hidden rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold text-brand-700 transition hover:border-brand-300 sm:inline-flex">
          All products
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {categories.map((c, i) => (
          <CategoryTile key={c.id} id={c.id} name={c.name} count={c.count} cover={covers.get(c.id)} index={i} />
        ))}
      </div>
    </section>
  );
}

function CategoryTile({
  id,
  name,
  count,
  cover,
  index,
}: {
  id: string;
  name: string;
  count: number;
  cover?: string;
  index: number;
}) {
  const ref = useReveal<HTMLAnchorElement>();
  return (
    <Link
      ref={ref}
      data-reveal
      style={{ "--reveal-delay": `${Math.min(index, 10) * 40}ms` } as React.CSSProperties}
      href={catalogHref({ cat: id })}
      className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-line bg-white p-4 pt-5 transition hover:-translate-y-1 hover:border-brand-300 hover:shadow-[0_14px_34px_-22px_rgb(16_36_29/0.45)]"
    >
      <span className="pointer-events-none absolute -top-10 -right-10 size-24 rounded-full bg-brand-50 transition group-hover:scale-150" />
      {cover && (
        <span className="relative mb-3 block size-16 self-end">
          <Image
            src={cover}
            alt=""
            fill
            sizes="64px"
            draggable={false}
            className="no-save object-contain transition duration-500 group-hover:-rotate-6 group-hover:scale-110"
          />
        </span>
      )}
      <span>
        <span className="block text-sm leading-tight font-bold text-ink">{name}</span>
        <span className="mt-1 flex items-center gap-1 text-xs font-medium text-muted">
          {count} products
          <ArrowRightIcon width={12} height={12} className="transition-transform group-hover:translate-x-1" />
        </span>
      </span>
    </Link>
  );
}
