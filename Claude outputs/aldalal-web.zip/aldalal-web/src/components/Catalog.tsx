"use client";

import { Fragment, useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import {
  categories,
  categoryById,
  matches,
  products,
  searchTokens,
  sortProducts,
  SORT_OPTIONS,
  type Product,
  type SortKey,
} from "@/lib/catalog";
import { useCart } from "@/lib/cart";
import { useFavoriteSet } from "@/lib/favorites";
import { useReveal } from "@/lib/hooks";
import { setFilters, useFilters } from "@/lib/url-state";
import { ProductCard } from "./ProductCard";
import { ChevronDownIcon, CloseIcon, SearchIcon } from "./icons";

const PAGE = 24;

export function Catalog() {
  const filters = useFilters();
  const cartState = useCart();
  const favoriteSet = useFavoriteSet();

  const query = useDeferredValue(filters.q);
  const tokens = useMemo(() => searchTokens(query), [query]);
  const searched = useMemo(() => products.filter((p) => matches(p, tokens)), [tokens]);
  const counts = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of searched) m.set(p.category, (m.get(p.category) ?? 0) + 1);
    return m;
  }, [searched]);
  const results = useMemo(
    () => sortProducts(filters.cat ? searched.filter((p) => p.category === filters.cat) : searched, filters.sort),
    [searched, filters.cat, filters.sort],
  );

  // Render in pages; back to the first page whenever the filters change
  const viewKey = `${query}|${filters.cat}|${filters.sort}`;
  const [pager, setPager] = useState({ key: viewKey, limit: PAGE });
  const limit = pager.key === viewKey ? pager.limit : PAGE;
  const shown = results.slice(0, limit);
  const hasMore = results.length > limit;
  const showMore = useCallback(() => setPager({ key: viewKey, limit: limit + PAGE }), [viewKey, limit]);

  const sentinel = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = sentinel.current;
    if (!el || !hasMore) return;
    const io = new IntersectionObserver((entries) => entries[0].isIntersecting && showMore(), { rootMargin: "1400px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, [hasMore, showMore]);

  const grouped = filters.sort === "default" && !filters.cat;
  const groups = useMemo(() => groupByCategory(shown, grouped), [shown, grouped]);
  const eagerIds = new Set(shown.slice(0, 8).map((p) => p.id));

  const resultsRef = useRef<HTMLDivElement>(null);
  const pickCategory = useCallback((cat: string | null) => {
    setFilters({ cat });
    const top = resultsRef.current?.getBoundingClientRect().top ?? 0;
    if (top < 120) resultsRef.current?.scrollIntoView({ block: "start" });
  }, []);

  const activeCategory = filters.cat ? categoryById.get(filters.cat) : null;

  return (
    <>
      <CatalogHero title={activeCategory?.name ?? "All products"} count={results.length} query={query} />

      <FilterBar active={filters.cat} counts={counts} total={searched.length} onPick={pickCategory} />

      <div ref={resultsRef} className="mx-auto flex max-w-7xl scroll-mt-32 gap-8 px-4 pt-2 pb-16">
        <CategorySidebar active={filters.cat} counts={counts} total={searched.length} onPick={pickCategory} />

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center justify-between gap-3 py-4">
            <p className="text-sm text-muted" aria-live="polite">
              <span className="font-bold text-ink tabular-nums">{results.length}</span>{" "}
              {results.length === 1 ? "product" : "products"}
              {activeCategory && (
                <>
                  {" "}in <span className="font-semibold text-ink">{activeCategory.name}</span>
                </>
              )}
              {query.trim() && (
                <>
                  {" "}for “<span className="font-semibold text-ink">{query.trim()}</span>”
                </>
              )}
            </p>
            <div className="flex items-center gap-2">
              {(filters.q || filters.cat) && (
                <button
                  type="button"
                  onClick={() => setFilters({ q: "", cat: null })}
                  className="inline-flex items-center gap-1 rounded-full border border-line bg-white px-3 py-2 text-sm font-medium text-muted transition hover:border-brand-300 hover:text-brand-700"
                >
                  <CloseIcon width={14} height={14} />
                  Clear
                </button>
              )}
              <SortSelect value={filters.sort} onChange={(sort) => setFilters({ sort })} />
            </div>
          </div>

          {results.length === 0 ? (
            <EmptyState
              query={query}
              otherMatches={filters.cat ? searched.length : 0}
              onClearSearch={() => setFilters({ q: "" })}
              onAllCategories={() => pickCategory(null)}
            />
          ) : (
            groups.map((g, gi) => (
              <Fragment key={`${g.category ?? "all"}-${gi}`}>
                {g.category && (
                  <h2
                    className={`${gi === 0 ? "mt-0" : "mt-10"} mb-4 flex items-baseline gap-3 text-xl font-extrabold tracking-tight text-ink`}
                  >
                    {categoryById.get(g.category)?.name}
                    <span className="h-px flex-1 bg-line" />
                    <span className="text-sm font-medium text-muted tabular-nums">{counts.get(g.category)}</span>
                  </h2>
                )}
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-5 md:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
                  {g.items.map((p, i) => (
                    <ProductCard
                      key={p.id}
                      product={p}
                      index={i}
                      qty={cartState[p.id] ?? 0}
                      favorite={favoriteSet.has(p.id)}
                      eager={eagerIds.has(p.id)}
                      categoryName={grouped || filters.cat ? undefined : categoryById.get(p.category)?.name}
                    />
                  ))}
                </div>
              </Fragment>
            ))
          )}

          {hasMore && (
            <div ref={sentinel} className="flex justify-center py-10">
              <button
                type="button"
                onClick={showMore}
                className="rounded-full border border-line bg-white px-6 py-3 text-sm font-semibold text-brand-700 transition hover:-translate-y-0.5 hover:border-brand-300"
              >
                Show more ({results.length - limit} left)
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function CatalogHero({ title, count, query }: { title: string; count: number; query: string }) {
  return (
    <section className="border-b border-line bg-white">
      <div className="mx-auto max-w-7xl px-4 py-8 md:py-10">
        <p className="enter text-xs font-bold tracking-[0.18em] text-brand-600 uppercase">Price list</p>
        <h1 key={title} className="enter enter-1 mt-2 text-3xl font-extrabold tracking-tight text-ink md:text-4xl">
          {query.trim() ? `“${query.trim()}”` : title}
        </h1>
        <p className="enter enter-2 mt-2 text-sm text-muted">
          <span className="font-bold text-ink tabular-nums">{count}</span> products · photos and prices in USD · add to your
          order and send it on WhatsApp
        </p>
      </div>
    </section>
  );
}

type CategoryNavProps = {
  active: string | null;
  counts: Map<string, number>;
  total: number;
  onPick: (id: string | null) => void;
};

function FilterBar({ active, counts, total, onPick }: CategoryNavProps) {
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const box = scroller.current;
    const chip = box?.querySelector<HTMLElement>('[aria-pressed="true"]');
    if (!box || !chip) return;
    box.scrollTo({ left: chip.offsetLeft - box.clientWidth / 2 + chip.clientWidth / 2, behavior: "smooth" });
  }, [active]);

  const chip = (selected: boolean, dim: boolean) =>
    `shrink-0 rounded-full border px-4 py-2 text-sm font-semibold whitespace-nowrap transition ${
      selected
        ? "border-brand-500 bg-brand-500 text-white"
        : `border-line bg-white text-muted hover:border-brand-300 hover:text-brand-700 ${dim ? "opacity-45" : ""}`
    }`;

  return (
    <nav aria-label="Categories" className="sticky top-16 z-20 border-b border-line bg-canvas/95 backdrop-blur lg:hidden">
      <div ref={scroller} className="no-scrollbar mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-2.5">
        <button type="button" aria-pressed={!active} onClick={() => onPick(null)} className={chip(!active, false)}>
          All <span className="opacity-70 tabular-nums">{total}</span>
        </button>
        {categories.map((c) => {
          const n = counts.get(c.id) ?? 0;
          return (
            <button
              key={c.id}
              type="button"
              aria-pressed={active === c.id}
              onClick={() => onPick(c.id)}
              className={chip(active === c.id, n === 0)}
            >
              {c.name} <span className="opacity-70 tabular-nums">{n}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function CategorySidebar({ active, counts, total, onPick }: CategoryNavProps) {
  const item = (selected: boolean, dim: boolean) =>
    `flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-sm transition ${
      selected
        ? "bg-brand-50 font-semibold text-brand-700"
        : `text-muted hover:bg-canvas hover:text-ink ${dim ? "opacity-45" : ""}`
    }`;

  return (
    <aside className="hidden w-60 shrink-0 lg:block">
      <nav
        aria-label="Categories"
        className="sticky top-24 max-h-[calc(100dvh-8rem)] overflow-y-auto rounded-2xl border border-line bg-white p-3"
      >
        <h2 className="px-3 pt-1 pb-2 text-xs font-bold tracking-wider text-muted uppercase">Categories</h2>
        <ul className="grid gap-0.5">
          <li>
            <button type="button" aria-pressed={!active} onClick={() => onPick(null)} className={item(!active, false)}>
              All products <span className="text-xs tabular-nums opacity-70">{total}</span>
            </button>
          </li>
          {categories.map((c) => {
            const n = counts.get(c.id) ?? 0;
            const selected = active === c.id;
            return (
              <li key={c.id}>
                <button type="button" aria-pressed={selected} onClick={() => onPick(c.id)} className={item(selected, n === 0)}>
                  {c.name} <span className="text-xs tabular-nums opacity-70">{n}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}

function SortSelect({ value, onChange }: { value: SortKey; onChange: (v: SortKey) => void }) {
  return (
    <label className="relative flex items-center gap-2 text-sm text-muted">
      <span className="hidden sm:inline">Sort</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as SortKey)}
        className="h-10 appearance-none rounded-full border border-line bg-white pr-9 pl-4 font-medium text-ink outline-none focus:border-brand-400"
        aria-label="Sort products"
      >
        {SORT_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <ChevronDownIcon width={16} height={16} className="pointer-events-none absolute right-3 text-muted" />
    </label>
  );
}

function EmptyState({
  query,
  otherMatches,
  onClearSearch,
  onAllCategories,
}: {
  query: string;
  otherMatches: number;
  onClearSearch: () => void;
  onAllCategories: () => void;
}) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      data-reveal="zoom"
      className="flex flex-col items-center gap-3 rounded-2xl border border-line bg-white px-6 py-16 text-center"
    >
      <div className="grid size-16 place-items-center rounded-full bg-brand-50 text-brand-600">
        <SearchIcon width={28} height={28} />
      </div>
      <p className="text-lg font-bold">No products found</p>
      <p className="max-w-sm text-sm text-muted">
        {query.trim() ? <>Nothing matches “{query.trim()}” here. Try a brand name or a shorter word.</> : <>This category is empty.</>}
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        {otherMatches > 0 && (
          <button
            type="button"
            onClick={onAllCategories}
            className="rounded-full bg-brand-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-600"
          >
            See {otherMatches} {otherMatches === 1 ? "match" : "matches"} in all categories
          </button>
        )}
        {query.trim() && (
          <button
            type="button"
            onClick={onClearSearch}
            className="rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-brand-700 hover:bg-canvas"
          >
            Clear search
          </button>
        )}
      </div>
    </div>
  );
}

function groupByCategory(items: Product[], grouped: boolean) {
  if (!grouped) return [{ category: null as string | null, items }];
  const out: { category: string | null; items: Product[] }[] = [];
  for (const p of items) {
    const last = out[out.length - 1];
    if (last && last.category === p.category) last.items.push(p);
    else out.push({ category: p.category, items: [p] });
  }
  return out;
}
