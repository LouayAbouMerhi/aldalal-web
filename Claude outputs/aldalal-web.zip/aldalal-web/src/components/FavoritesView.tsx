"use client";

import Link from "next/link";
import { categoryById, formatPrice } from "@/lib/catalog";
import { cart, useCart } from "@/lib/cart";
import { favorites, useFavoriteProducts } from "@/lib/favorites";
import { toast } from "@/lib/toast";
import { ProductCard } from "./ProductCard";
import { RecentlyViewed } from "./HomeSections";
import { ArrowRightIcon, CartIcon, HeartIcon, TrashIcon } from "./icons";

export function FavoritesView() {
  const items = useFavoriteProducts();
  const cartState = useCart();
  const total = items.reduce((sum, p) => sum + (p.price ?? 0), 0);

  return (
    <>
      <section className="border-b border-line bg-white py-8 md:py-10">
        <div className="mx-auto max-w-7xl px-4">
          <h1 className="enter flex items-center gap-3 text-3xl font-extrabold tracking-tight text-ink md:text-4xl">
            <HeartIcon filled className="size-8 text-rose-500 md:size-9" />
            Saved products
          </h1>
          <p className="mt-2 text-sm text-muted">
            {items.length === 0
              ? "Tap the heart on any product to keep it here."
              : `${items.length} saved · ${formatPrice(total)} if you take one of each`}
          </p>
        </div>
      </section>

      {items.length === 0 ? (
        <div className="mx-auto grid max-w-md place-items-center gap-4 px-4 py-20 text-center">
          <span className="grid size-20 place-items-center rounded-full bg-rose-50 text-rose-400">
            <HeartIcon width={34} height={34} />
          </span>
          <h2 className="text-xl font-bold">Nothing saved yet</h2>
          <p className="text-sm text-muted">
            Browse the catalog and tap the heart on a product to save it for later. Saved products stay on this device.
          </p>
          <Link
            href="/products"
            className="mt-2 inline-flex h-12 items-center gap-2 rounded-full bg-brand-500 px-6 font-semibold text-white transition hover:bg-brand-600"
          >
            Browse products
            <ArrowRightIcon />
          </Link>
        </div>
      ) : (
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="mb-5 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                items.forEach((p) => cart.add(p.id));
                toast({ title: `${items.length} products added to your order` });
              }}
              className="inline-flex h-11 items-center gap-2 rounded-full bg-brand-500 px-5 text-sm font-semibold text-white transition hover:bg-brand-600"
            >
              <CartIcon width={18} height={18} />
              Add all to order
            </button>
            <button
              type="button"
              onClick={() => {
                favorites.clear();
                toast({ title: "Saved products cleared" });
              }}
              className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-semibold text-muted transition hover:border-rose-200 hover:text-rose-600"
            >
              <TrashIcon width={18} height={18} />
              Clear all
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4 xl:grid-cols-5">
            {items.map((p, i) => (
              <ProductCard
                key={p.id}
                product={p}
                index={i}
                qty={cartState[p.id] ?? 0}
                favorite
                categoryName={categoryById.get(p.category)?.name}
              />
            ))}
          </div>
        </div>
      )}

      <RecentlyViewed />
    </>
  );
}
