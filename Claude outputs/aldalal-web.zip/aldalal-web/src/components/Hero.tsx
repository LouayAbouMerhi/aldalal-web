"use client";

import Image from "next/image";
import Link from "next/link";
import { site } from "@/config/site";
import { categories, products } from "@/lib/catalog";
import { catalogHref } from "@/lib/links";
import { whatsappUrl } from "@/lib/whatsapp";
import { ArrowRightIcon, PinIcon, WhatsAppIcon } from "./icons";

type Photo = { src: string; alt: string };

export function Hero({ photos }: { photos: Photo[] }) {
  const priced = products.filter((p) => p.price !== null).length;

  return (
    <section className="relative overflow-hidden border-b border-line bg-gradient-to-b from-brand-50 to-canvas">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:py-16 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:py-20">
        <div>
          <span className="enter inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-brand-700">
            <PinIcon width={14} height={14} />
            {site.address.replace(/, Lebanon$/, "")}
          </span>

          <h1 className="enter enter-1 mt-5 text-4xl leading-[1.05] font-extrabold tracking-tight text-ink sm:text-5xl lg:text-6xl">
            Everything your
            <span className="block text-brand-600">shelves need.</span>
          </h1>

          <p className="enter enter-2 mt-5 max-w-lg text-[15px] leading-relaxed text-muted sm:text-base">
            The full {site.fullName} price list — {products.length} products with photos and prices in USD. Build your order
            and send it to us on WhatsApp in one tap.
          </p>

          <div className="enter enter-3 mt-7 flex flex-wrap items-center gap-3">
            <Link
              href="/products"
              className="group inline-flex h-12 items-center gap-2 rounded-full bg-brand-500 px-6 font-bold text-white shadow-sm transition hover:bg-brand-600 active:scale-95"
            >
              Browse the catalog
              <ArrowRightIcon className="transition-transform group-hover:translate-x-1" />
            </Link>
            <a
              href={whatsappUrl(`Hello ${site.name}, I would like to order from your price list.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-12 items-center gap-2 rounded-full border border-wa-600/30 bg-white px-6 font-semibold text-wa-700 transition hover:bg-wa-600 hover:text-white"
            >
              <WhatsAppIcon />
              Order on WhatsApp
            </a>
          </div>

          <dl className="enter enter-4 mt-9 flex flex-wrap gap-x-8 gap-y-4">
            {[
              { value: products.length, label: "Products" },
              { value: categories.length, label: "Categories" },
              { value: priced, label: "Priced in USD" },
            ].map((stat) => (
              <div key={stat.label}>
                <dt className="sr-only">{stat.label}</dt>
                <dd>
                  <span className="block text-2xl font-extrabold text-ink tabular-nums">{stat.value}</span>
                  <span className="text-xs font-semibold tracking-wide text-muted uppercase">{stat.label}</span>
                </dd>
              </div>
            ))}
          </dl>
        </div>

        {/* A neat grid of real products instead of decoration */}
        <div className="enter enter-2 mx-auto grid w-full max-w-md grid-cols-3 gap-3 sm:gap-4 lg:mx-0 lg:ml-auto">
          {photos.slice(0, 6).map((photo, i) => (
            <Link
              key={photo.src}
              href="/products"
              aria-label="Browse the catalog"
              className={`no-save flex aspect-square items-center justify-center rounded-2xl border border-line bg-white p-2.5 transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-[0_12px_30px_-18px_rgb(16_36_29/0.4)] ${
                i % 2 ? "sm:translate-y-3" : ""
              }`}
            >
              <span className="relative size-full">
                <Image src={photo.src} alt="" fill sizes="140px" draggable={false} className="object-contain" />
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 pb-8">
        <div className="no-scrollbar flex gap-2 overflow-x-auto">
          {categories.slice(0, 10).map((c) => (
            <Link
              key={c.id}
              href={catalogHref({ cat: c.id })}
              className="shrink-0 rounded-full border border-line bg-white px-4 py-2 text-sm font-semibold text-muted whitespace-nowrap transition hover:border-brand-300 hover:text-brand-700"
            >
              {c.name} <span className="text-xs opacity-60 tabular-nums">{c.count}</span>
            </Link>
          ))}
          <Link
            href="/products"
            className="shrink-0 rounded-full bg-ink px-4 py-2 text-sm font-semibold text-white whitespace-nowrap transition hover:bg-brand-800"
          >
            All categories →
          </Link>
        </div>
      </div>
    </section>
  );
}
