"use client";

import Link from "next/link";
import { site, whatsappDisplay } from "@/config/site";
import { useRecentProducts } from "@/lib/recent";
import { useReveal } from "@/lib/hooks";
import { whatsappUrl } from "@/lib/whatsapp";
import { ProductRail } from "./ProductRail";
import { CartIcon, ClockIcon, DownloadIcon, PhoneIcon, TagIcon, WhatsAppIcon } from "./icons";

const FEATURES = [
  { icon: TagIcon, title: "Real photos and prices", text: "Every product in the price list, with its photo and price in US dollars." },
  { icon: CartIcon, title: "Build your order", text: "Add what you need, set the quantities, and we price anything that's missing." },
  { icon: WhatsAppIcon, title: "Send it on WhatsApp", text: "One tap sends your whole order to us, ready to confirm." },
  { icon: DownloadIcon, title: "Works like an app", text: "Add it to your phone's home screen and browse even without internet." },
];

export function FeatureStrip() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} data-reveal className="mx-auto max-w-7xl px-4 py-10">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {FEATURES.map(({ icon: Icon, title, text }, i) => (
          <div
            key={title}
            style={{ "--reveal-delay": `${i * 70}ms` } as React.CSSProperties}
            className="group rounded-2xl border border-line bg-white p-5 transition hover:-translate-y-1 hover:border-brand-200 hover:shadow-[0_14px_34px_-22px_rgb(16_36_29/0.45)]"
          >
            <span className="grid size-11 place-items-center rounded-2xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-500 group-hover:text-white">
              <Icon />
            </span>
            <h3 className="mt-3 font-bold text-ink">{title}</h3>
            <p className="mt-1 text-sm text-muted">{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function RecentlyViewed({ exclude }: { exclude?: string }) {
  const items = useRecentProducts(exclude);
  if (items.length < 3) return null;
  return (
    <ProductRail
      title="Recently viewed"
      subtitle="Pick up where you left off"
      items={items}
      icon={<ClockIcon className="text-brand-500" />}
    />
  );
}

export function OrderCta() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} data-reveal className="mx-auto max-w-7xl px-4 py-12">
      <div className="relative isolate overflow-hidden rounded-3xl border border-brand-200 bg-brand-50 px-6 py-12 text-center md:px-12 md:py-14">
        <h2 className="text-3xl font-extrabold tracking-tight text-ink md:text-4xl">Ready to order?</h2>
        <p className="mx-auto mt-3 max-w-lg text-muted">
          Add products to your order and send the list to us on WhatsApp, or call the shop — we&apos;re on the main road in{" "}
          {site.address.replace(/, Lebanon$/, "").replace(/^Sibline, /, "Sibline, ")}.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/products"
            className="inline-flex h-12 items-center gap-2 rounded-full bg-brand-500 px-6 font-bold text-white shadow-sm transition hover:bg-brand-600"
          >
            <CartIcon />
            Start an order
          </Link>
          <a
            href={whatsappUrl(`Hello ${site.name}, I would like to order from your price list.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-12 items-center gap-2 rounded-full bg-wa-600 px-6 font-semibold text-white transition hover:bg-wa-700"
          >
            <WhatsAppIcon />
            WhatsApp {whatsappDisplay}
          </a>
          {site.phones.map((p) => (
            <a
              key={p.tel}
              href={`tel:${p.tel}`}
              className="inline-flex h-12 items-center gap-2 rounded-full border border-line bg-white px-5 font-semibold text-ink transition hover:border-brand-300 hover:text-brand-700"
            >
              <PhoneIcon width={18} height={18} />
              {p.display}
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
