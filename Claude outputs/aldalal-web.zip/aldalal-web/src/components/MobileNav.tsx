"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "motion/react";
import { formatPrice } from "@/lib/catalog";
import { CartIcon, GridIcon, HeartIcon, HomeIcon } from "./icons";

type Props = {
  cartPieces: number;
  cartSubtotal: number;
  favoriteCount: number;
  onOpenCart: () => void;
};

/** App-style bottom bar, phones and tablets only. */
export function MobileNav({ cartPieces, cartSubtotal, favoriteCount, onOpenCart }: Props) {
  const pathname = usePathname();
  const items = [
    { href: "/", label: "Home", icon: HomeIcon, active: pathname === "/" },
    { href: "/products", label: "Catalog", icon: GridIcon, active: pathname.startsWith("/product") },
    { href: "/favorites", label: "Saved", icon: HeartIcon, active: pathname.startsWith("/favorites"), badge: favoriteCount },
  ];

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 lg:hidden">
      {cartPieces > 0 && (
        <motion.button
          type="button"
          onClick={onOpenCart}
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ type: "spring", stiffness: 380, damping: 30 }}
          className="mx-3 mb-2 flex h-12 w-[calc(100%-1.5rem)] items-center justify-between gap-3 rounded-2xl bg-brand-500 px-4 text-white shadow-lg shadow-brand-500/25"
        >
          <span className="flex items-center gap-2 text-sm font-semibold">
            <CartIcon width={18} height={18} />
            View order · {cartPieces} pcs
          </span>
          <span className="text-sm font-bold tabular-nums">{formatPrice(cartSubtotal)}</span>
        </motion.button>
      )}

      <nav
        aria-label="Main"
        className="flex items-stretch justify-around border-t border-line bg-white pt-1 pb-[max(0.5rem,env(safe-area-inset-bottom))]"
      >
        {items.map(({ href, label, icon: Icon, active, badge }) => (
          <Link
            key={href}
            href={href}
            className={`relative flex flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-semibold transition ${
              active ? "text-brand-600" : "text-muted"
            }`}
            aria-current={active ? "page" : undefined}
          >
            <span className="relative">
              <Icon width={22} height={22} />
              {!!badge && badge > 0 && (
                <span className="absolute -top-1.5 -right-2 grid h-4 min-w-4 place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white tabular-nums">
                  {badge > 99 ? "99+" : badge}
                </span>
              )}
            </span>
            {label}
            {active && <motion.span layoutId="mobile-nav-dot" className="absolute -top-0.5 h-1 w-8 rounded-full bg-brand-500" />}
          </Link>
        ))}
        <button
          type="button"
          onClick={onOpenCart}
          className="relative flex flex-1 flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-semibold text-muted"
        >
          <span className="relative">
            <CartIcon width={22} height={22} />
            {cartPieces > 0 && (
              <span className="absolute -top-1.5 -right-2 grid h-4 min-w-4 place-items-center rounded-full bg-brand-500 px-1 text-[10px] font-bold text-white tabular-nums">
                {cartPieces > 99 ? "99+" : cartPieces}
              </span>
            )}
          </span>
          Order
        </button>
      </nav>
    </div>
  );
}
