"use client";

import Link from "next/link";
import Image from "next/image";
import { site, whatsappDisplay } from "@/config/site";
import { categories, lastUpdated, products } from "@/lib/catalog";
import { catalogHref } from "@/lib/links";
import { whatsappUrl } from "@/lib/whatsapp";
import { InstallButton } from "./InstallPrompt";
import { PhoneIcon, PinIcon, WhatsAppIcon } from "./icons";

export function SiteFooter() {
  const updated = new Date(lastUpdated).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Beirut",
  });

  return (
    <footer className="relative mt-16 border-t border-line bg-white text-muted">

      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-14 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <Image src="/logo.png" alt="" width={48} height={48} className="size-12 rounded-2xl ring-1 ring-line" />
            <div>
              <p className="text-xl font-extrabold text-ink">{site.name}</p>
              <p className="text-xs tracking-wide text-muted">For General Trading</p>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm text-muted">
            {products.length} products across {categories.length} categories — personal care, home care and more, at wholesale
            prices in US dollars.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            <a
              href={whatsappUrl(`Hello ${site.name}, I have a question about your price list.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-wa-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-wa-700"
            >
              <WhatsAppIcon width={18} height={18} />
              WhatsApp {whatsappDisplay}
            </a>
            <InstallButton />
          </div>
        </div>

        <nav aria-label="Categories">
          <p className="text-xs font-semibold tracking-widest text-muted uppercase">Top categories</p>
          <ul className="mt-4 grid gap-2 text-sm">
            {categories.slice(0, 7).map((c) => (
              <li key={c.id}>
                <Link href={catalogHref({ cat: c.id })} className="text-ink transition hover:text-brand-700">
                  {c.name} <span className="text-muted tabular-nums">{c.count}</span>
                </Link>
              </li>
            ))}
            <li>
              <Link href="/products" className="font-semibold text-brand-700 underline-offset-4 hover:underline">
                See all products →
              </Link>
            </li>
          </ul>
        </nav>

        <div>
          <p className="text-xs font-semibold tracking-widest text-muted uppercase">Contact</p>
          <ul className="mt-4 grid gap-3 text-sm">
            {site.phones.map((p) => (
              <li key={p.tel}>
                <a href={`tel:${p.tel}`} className="inline-flex items-center gap-2 text-ink transition hover:text-brand-700">
                  <PhoneIcon width={16} height={16} />
                  {p.display}
                </a>
              </li>
            ))}
            <li>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(site.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-start gap-2 text-ink transition hover:text-brand-700"
              >
                <PinIcon width={16} height={16} className="mt-0.5 shrink-0" />
                {site.address}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="relative border-t border-line bg-canvas">
        <div className="mx-auto flex max-w-7xl flex-col gap-1 px-4 pt-5 pb-28 text-xs text-muted lg:pb-5 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date(lastUpdated).getFullYear()} {site.fullName}. Prices in USD and may change without notice.</p>
          <p>Price list updated {updated}</p>
        </div>
      </div>
    </footer>
  );
}
