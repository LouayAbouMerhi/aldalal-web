"use client";

import Link from "next/link";
import { useEffect, useState, ViewTransition } from "react";
import { site, whatsappDisplay } from "@/config/site";
import { categoryById, formatPrice, type Product } from "@/lib/catalog";
import { cart, useCart } from "@/lib/cart";
import { favorites, useFavoriteSet } from "@/lib/favorites";
import { catalogHref } from "@/lib/links";
import { recent } from "@/lib/recent";
import { toast } from "@/lib/toast";
import { productQuestion, whatsappUrl } from "@/lib/whatsapp";
import { ProductImage } from "./ProductImage";
import { ProductRail } from "./ProductRail";
import { QtyStepper } from "./QtyStepper";
import { RecentlyViewed } from "./HomeSections";
import {
  ArrowLeftIcon,
  CartIcon,
  CheckIcon,
  HeartIcon,
  PhoneIcon,
  ShareIcon,
  TagIcon,
  WhatsAppIcon,
} from "./icons";

export function ProductView({ product, related }: { product: Product; related: Product[] }) {
  const qty = useCart()[product.id] ?? 0;
  const favorite = useFavoriteSet().has(product.id);
  const category = categoryById.get(product.category);
  const [pending, setPending] = useState(1);

  useEffect(() => {
    recent.add(product.id);
  }, [product.id]);

  const add = () => {
    cart.add(product.id, pending);
    toast({
      title: `${pending} × added to your order`,
      description: product.name,
      image: product.image?.src ?? null,
      action: { label: "View", onClick: () => window.dispatchEvent(new CustomEvent("aldalal:open-cart")) },
    });
  };

  const share = async () => {
    const url = window.location.href;
    const data = { title: product.name, text: `${product.name}${product.price !== null ? ` — ${formatPrice(product.price)}` : ""}`, url };
    try {
      if (navigator.share) {
        await navigator.share(data);
        return;
      }
      await navigator.clipboard.writeText(url);
      toast({ title: "Link copied", description: product.name });
    } catch {
      /* the customer cancelled the share sheet */
    }
  };

  return (
    <>
      <div className="border-b border-line bg-white">
        <nav aria-label="Breadcrumb" className="mx-auto max-w-7xl px-4 py-4 text-sm text-muted">
          <ol className="flex flex-wrap items-center gap-2">
            <li>
              <Link href="/" className="transition hover:text-brand-700">
                Home
              </Link>
            </li>
            <li aria-hidden>/</li>
            <li>
              <Link href="/products" className="transition hover:text-brand-700">
                Products
              </Link>
            </li>
            {category && (
              <>
                <li aria-hidden>/</li>
                <li>
                  <Link href={catalogHref({ cat: category.id })} className="transition hover:text-brand-700">
                    {category.name}
                  </Link>
                </li>
              </>
            )}
          </ol>
        </nav>
      </div>

      <div className="mx-auto max-w-7xl px-4 pt-6">
        <div
          className="enter grid gap-6 rounded-3xl border border-line bg-white p-4 md:p-8 lg:grid-cols-2 lg:gap-10"
        >
          <div className="relative overflow-hidden rounded-2xl border border-line bg-canvas p-4">
            <ViewTransition name={`p-${product.id}`} share="morph" default="none">
              <ProductImage
                product={product}
                eager
                sizes="(min-width: 1024px) 520px, 90vw"
                className="mx-auto max-w-[24rem] transition-transform duration-700 hover:scale-105"
              />
            </ViewTransition>
            <button
              type="button"
              onClick={() => {
                favorites.toggle(product.id);
                toast({
                  title: favorite ? "Removed from favorites" : "Saved to favorites",
                  description: product.name,
                  image: product.image?.src ?? null,
                });
              }}
              aria-pressed={favorite}
              className={`absolute top-4 right-4 grid size-11 place-items-center rounded-full shadow-sm transition active:scale-90 ${
                favorite ? "bg-rose-50 text-rose-500 ring-1 ring-rose-200" : "bg-white text-slate-300 ring-1 ring-line hover:text-rose-500"
              }`}
              aria-label={favorite ? "Remove from favorites" : "Save to favorites"}
            >
              <HeartIcon filled={favorite} />
            </button>
          </div>

          <div className="flex flex-col">
            {category && (
              <Link
                href={catalogHref({ cat: category.id })}
                className="inline-flex w-fit items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1.5 text-xs font-bold tracking-wide text-brand-700 uppercase transition hover:bg-brand-100"
              >
                <TagIcon width={14} height={14} />
                {category.name}
              </Link>
            )}
            <h1 className="mt-3 text-2xl leading-tight font-extrabold tracking-tight text-ink md:text-4xl">
              {product.name}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-3">
              {product.price === null ? (
                <span className="inline-flex items-center rounded-full bg-gold-100 px-4 py-2 text-sm font-bold text-gold-600">
                  Ask for price
                </span>
              ) : (
                <>
                  <span className="text-4xl font-black tracking-tight text-ink tabular-nums">
                    {formatPrice(product.price)}
                  </span>
                  <span className="text-sm text-muted">per piece, USD</span>
                </>
              )}
            </div>

            {product.price === null && (
              <p className="mt-3 text-sm text-muted">
                This item has no listed price yet. Add it to your order and we&apos;ll confirm the price on WhatsApp.
              </p>
            )}

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <QtyStepper value={pending} min={1} label={product.name} onChange={setPending} />
              <button
                type="button"
                onClick={add}
                className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full bg-brand-500 px-6 font-bold text-white transition hover:bg-brand-600 active:scale-[0.98]"
              >
                <CartIcon />
                Add to order
              </button>
            </div>

            {qty > 0 && (
              <p className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-wa-700">
                <CheckIcon width={16} height={16} />
                {qty} in your order
                <button
                  type="button"
                  onClick={() => window.dispatchEvent(new CustomEvent("aldalal:open-cart"))}
                  className="underline underline-offset-4"
                >
                  View order
                </button>
              </p>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href={whatsappUrl(productQuestion(product))}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex h-11 items-center gap-2 rounded-full bg-wa-600 px-5 text-sm font-semibold text-white transition hover:bg-wa-700"
              >
                <WhatsAppIcon width={18} height={18} />
                Ask on WhatsApp
              </a>
              <button
                type="button"
                onClick={share}
                className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-semibold text-brand-700 transition hover:bg-canvas"
              >
                <ShareIcon width={18} height={18} />
                Share
              </button>
              <Link
                href="/products"
                className="inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-semibold text-muted transition hover:bg-canvas"
              >
                <ArrowLeftIcon width={18} height={18} />
                Keep browsing
              </Link>
            </div>

            <dl className="mt-8 grid gap-3 border-t border-line pt-6 text-sm">
              <div className="flex justify-between gap-4">
                <dt className="text-muted">Order by phone</dt>
                <dd className="flex flex-wrap justify-end gap-3 font-medium">
                  {site.phones.map((p) => (
                    <a key={p.tel} href={`tel:${p.tel}`} className="inline-flex items-center gap-1.5 text-brand-700 hover:underline">
                      <PhoneIcon width={14} height={14} />
                      {p.display}
                    </a>
                  ))}
                </dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">WhatsApp orders</dt>
                <dd className="font-medium">{whatsappDisplay}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted">Pick up</dt>
                <dd className="text-right font-medium">{site.address}</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <ProductRail
          title={category ? `More in ${category.name}` : "You may also like"}
          subtitle="Products from the same shelf"
          items={related}
          href={category ? catalogHref({ cat: category.id }) : "/products"}
        />
      )}
      <RecentlyViewed exclude={product.id} />
    </>
  );
}
