"use client";

import Image from "next/image";
import type { CSSProperties } from "react";
import { site } from "@/config/site";
import type { Product } from "@/lib/catalog";
import { ImageOffIcon } from "./icons";

/** Faint repeating shop name drawn over each photo. */
const watermarkUrl = (() => {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="190" height="190"><text x="95" y="100" font-family="system-ui, sans-serif" font-size="15" font-weight="700" fill="rgb(16 36 29 / 0.09)" text-anchor="middle" transform="rotate(-24 95 95)">${site.name}</text></svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
})();

type Props = {
  product: Product;
  sizes: string;
  className?: string;
  /** Load immediately (for photos visible on first paint). */
  eager?: boolean;
  /** Small thumbnails skip the watermark. */
  plain?: boolean;
};

/**
 * Square product photo.
 * Photos are protected: no right-click menu, no dragging, no long-press save,
 * and a transparent layer sits on top so the browser never targets the image.
 */
export function ProductImage({ product, sizes, className = "", eager = false, plain = false }: Props) {
  const watermarked = site.protectPhotos && !plain && product.image;

  return (
    <div
      className={`no-save relative aspect-square overflow-hidden bg-white ${watermarked ? "watermark" : ""} ${className}`}
      style={watermarked ? ({ "--watermark": watermarkUrl } as CSSProperties) : undefined}
      onContextMenu={site.protectPhotos ? (e) => e.preventDefault() : undefined}
    >
      {product.image ? (
        <Image
          src={product.image.src}
          alt={product.name}
          fill
          sizes={sizes}
          loading={eager ? "eager" : "lazy"}
          draggable={false}
          className="object-contain p-2 select-none"
        />
      ) : (
        <div className="grid h-full place-items-center text-slate-300">
          <ImageOffIcon width={36} height={36} />
        </div>
      )}
      {site.protectPhotos && <span className="photo-guard" aria-hidden />}
    </div>
  );
}
