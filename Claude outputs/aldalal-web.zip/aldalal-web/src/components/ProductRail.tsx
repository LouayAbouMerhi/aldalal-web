"use client";

import Link from "next/link";
import { useRef } from "react";
import { type Product } from "@/lib/catalog";
import { useCart } from "@/lib/cart";
import { useFavoriteSet } from "@/lib/favorites";
import { useReveal } from "@/lib/hooks";
import { ProductCard } from "./ProductCard";
import { ArrowLeftIcon, ArrowRightIcon } from "./icons";

type Props = {
  title: string;
  subtitle?: string;
  items: Product[];
  href?: string;
  icon?: React.ReactNode;
  tone?: "light" | "dark";
};

/** Horizontal, snapping row of product cards with arrows on desktop. */
export function ProductRail({ title, subtitle, items, href, icon, tone = "light" }: Props) {
  const scroller = useRef<HTMLDivElement>(null);
  const cartState = useCart();
  const favoriteSet = useFavoriteSet();
  const reveal = useReveal<HTMLDivElement>();

  if (items.length === 0) return null;

  const scrollBy = (dir: 1 | -1) => {
    const box = scroller.current;
    if (!box) return;
    box.scrollBy({ left: dir * Math.max(240, box.clientWidth * 0.8), behavior: "smooth" });
  };

  const dark = tone === "dark";

  return (
    <section ref={reveal} data-reveal className="mx-auto max-w-7xl px-4 py-8">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <h2 className={`flex items-center gap-2 text-2xl font-extrabold tracking-tight ${dark ? "text-white" : "text-ink"}`}>
            {icon}
            {title}
          </h2>
          {subtitle && <p className={`mt-1 text-sm ${dark ? "text-brand-100" : "text-muted"}`}>{subtitle}</p>}
        </div>
        <div className="flex items-center gap-2">
          {href && (
            <Link
              href={href}
              className={`hidden rounded-full px-4 py-2 text-sm font-semibold transition sm:inline-flex ${
                dark ? "bg-white/10 text-white ring-1 ring-white/20 hover:bg-white/20" : "border border-line bg-white text-brand-700 hover:border-brand-300"
              }`}
            >
              See all
            </Link>
          )}
          <div className="hidden gap-1.5 lg:flex">
            <button
              type="button"
              onClick={() => scrollBy(-1)}
              className={`grid size-10 place-items-center rounded-full transition ${
                dark ? "bg-white/10 text-white hover:bg-white/20" : "border border-line bg-white text-brand-700 hover:border-brand-300 hover:bg-brand-50"
              }`}
              aria-label="Scroll left"
            >
              <ArrowLeftIcon width={18} height={18} />
            </button>
            <button
              type="button"
              onClick={() => scrollBy(1)}
              className={`grid size-10 place-items-center rounded-full transition ${
                dark ? "bg-white/10 text-white hover:bg-white/20" : "border border-line bg-white text-brand-700 hover:border-brand-300 hover:bg-brand-50"
              }`}
              aria-label="Scroll right"
            >
              <ArrowRightIcon width={18} height={18} />
            </button>
          </div>
        </div>
      </div>

      <div
        ref={scroller}
        className="no-scrollbar -mx-4 -my-2 flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 py-4 sm:gap-5"
      >
        {items.map((p, i) => (
          <ProductCard
            key={p.id}
            product={p}
            index={i}
            rail
            qty={cartState[p.id] ?? 0}
            favorite={favoriteSet.has(p.id)}
          />
        ))}
        {href && (
          <Link
            href={href}
            className="flex w-[12.5rem] shrink-0 snap-start flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-line text-sm font-semibold text-brand-700 transition hover:border-brand-400 hover:bg-white sm:w-[14rem]"
          >
            <ArrowRightIcon />
            See all
          </Link>
        )}
      </div>
    </section>
  );
}
