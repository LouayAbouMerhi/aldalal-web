"use client";

import Link from "next/link";
import { memo, ViewTransition } from "react";
import { formatPrice, type Product } from "@/lib/catalog";
import { cart } from "@/lib/cart";
import { favorites } from "@/lib/favorites";
import { useReveal } from "@/lib/hooks";
import { toast } from "@/lib/toast";
import { ProductImage } from "./ProductImage";
import { QtyStepper } from "./QtyStepper";
import { HeartIcon, PlusIcon } from "./icons";

type Props = {
  product: Product;
  qty: number;
  favorite: boolean;
  categoryName?: string;
  eager?: boolean;
  index?: number;
  /** Cards inside a horizontal rail get a fixed width. */
  rail?: boolean;
};

export function Price({ price, className = "" }: { price: number | null; className?: string }) {
  if (price === null) {
    return (
      <span
        className={`inline-flex items-center rounded-full bg-gold-100 px-2 py-0.5 text-xs font-semibold text-gold-600 ${className}`}
      >
        Ask for price
      </span>
    );
  }
  return <span className={`font-extrabold tracking-tight text-ink tabular-nums ${className}`}>{formatPrice(price)}</span>;
}

export function FavoriteButton({
  product,
  favorite,
  className = "",
}: {
  product: Product;
  favorite: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        favorites.toggle(product.id);
        toast({
          title: favorite ? "Removed from saved" : "Saved for later",
          description: product.name,
          image: product.image?.src ?? null,
        });
      }}
      aria-pressed={favorite}
      aria-label={favorite ? `Remove ${product.name} from saved` : `Save ${product.name}`}
      className={`grid size-8 place-items-center rounded-full transition active:scale-90 ${
        favorite ? "bg-rose-50 text-rose-500" : "bg-white/90 text-slate-300 hover:text-rose-400"
      } ${className}`}
    >
      <HeartIcon filled={favorite} width={17} height={17} />
    </button>
  );
}

export const ProductCard = memo(function ProductCard({
  product,
  qty,
  favorite,
  categoryName,
  eager,
  index = 0,
  rail = false,
}: Props) {
  const reveal = useReveal<HTMLElement>();

  return (
    <article
      ref={reveal}
      data-reveal
      style={{ "--reveal-delay": `${Math.min(index, 9) * 40}ms` } as React.CSSProperties}
      className={rail ? "w-[12.5rem] shrink-0 snap-start sm:w-[14rem]" : "card-shell"}
    >
      <div className="group/card relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-white transition duration-300 hover:-translate-y-0.5 hover:border-brand-200 hover:shadow-[0_12px_30px_-18px_rgb(16_36_29/0.4)]">
        <Link
          href={`/product/${product.id}`}
          className="flex flex-1 flex-col focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-brand-500"
        >
          <div className="relative overflow-hidden">
            <ViewTransition name={`p-${product.id}`} share="morph" default="none">
              <ProductImage
                product={product}
                eager={eager}
                sizes="(min-width: 1280px) 240px, (min-width: 640px) 30vw, 45vw"
                className="transition-transform duration-500 ease-[cubic-bezier(.16,1,.3,1)] group-hover/card:scale-[1.04]"
              />
            </ViewTransition>
          </div>
          <div className="flex flex-1 flex-col gap-1 px-3 pt-2.5">
            {categoryName && (
              <span className="text-[10px] font-bold tracking-[0.08em] text-brand-600 uppercase">{categoryName}</span>
            )}
            <h3 className="line-clamp-3 text-[13.5px] leading-snug font-semibold text-ink" title={product.name}>
              {product.name}
            </h3>
          </div>
        </Link>

        <div className="flex items-center justify-between gap-2 px-3 pt-2 pb-3">
          <Price price={product.price} className="text-[17px]" />
          {qty > 0 ? (
            <QtyStepper size="sm" value={qty} label={product.name} onChange={(q) => cart.setQty(product.id, q)} />
          ) : (
            <button
              type="button"
              onClick={() => {
                cart.add(product.id);
                toast({
                  title: "Added to your order",
                  description: product.name,
                  image: product.image?.src ?? null,
                  action: { label: "View", onClick: () => window.dispatchEvent(new CustomEvent("aldalal:open-cart")) },
                });
              }}
              className="grid size-9 shrink-0 place-items-center rounded-full bg-brand-500 text-white transition hover:bg-brand-600 active:scale-90"
              aria-label={`Add ${product.name} to cart`}
            >
              <PlusIcon width={18} height={18} />
            </button>
          )}
        </div>

        <FavoriteButton
          product={product}
          favorite={favorite}
          className="absolute top-2 right-2 z-10 opacity-0 transition group-hover/card:opacity-100 focus-visible:opacity-100 max-lg:opacity-100"
        />
      </div>
    </article>
  );
});
