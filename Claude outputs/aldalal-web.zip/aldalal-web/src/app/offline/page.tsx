import type { Metadata } from "next";
import Link from "next/link";
import { site } from "@/config/site";

export const metadata: Metadata = {
  title: `Offline | ${site.name}`,
  robots: { index: false },
};

export default function OfflinePage() {
  return (
    <div className="mx-auto grid max-w-md place-items-center gap-4 px-4 py-24 text-center">
      <span className="grid size-20 place-items-center rounded-full bg-brand-50 text-4xl">📡</span>
      <h1 className="text-2xl font-extrabold text-brand-950">You&apos;re offline</h1>
      <p className="text-sm text-slate-600">
        This page hasn&apos;t been saved on your phone yet. Products you already opened still work offline — try the catalog or
        your saved products.
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <Link href="/products" className="rounded-full bg-brand-700 px-5 py-2.5 text-sm font-semibold text-white">
          Open the catalog
        </Link>
        <Link href="/" className="rounded-full px-5 py-2.5 text-sm font-semibold text-brand-800 ring-1 ring-slate-300">
          Home
        </Link>
      </div>
    </div>
  );
}
